from django.db import models

# Create your models here.
class Contact_complaint(models.Model):
	gender=[('MALE','MALE'),('FEMALE','FEMALE')]
	c_name=models.CharField(max_length=100)
	c_mobileno=models.IntegerField()
	c_email=models.EmailField(max_length=40)
	c_gender=models.CharField(max_length=10,choices=gender)
	c_complaint=models.CharField(max_length=2000)

	def __str__(self):
		return self.c_name